// import { Component } from "react";

// class Firstclasscomp extends Component{
//     render(){
//         return(
//            <div>
//             <h2>class comp</h2>
//             <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptates vel officia tempore aperiam est fuga laudantium quis eligendi dolorem velit. Dignissimos impedit deserunt laudantium blanditiis cupiditate repudiandae sapiente at doloribus?</p>
//            </div> 
//         )
//     }
// }
// export default Firstclasscomp

//rcc 
import React, { Component } from 'react'

export default class Firstclasscomp extends Component {
  render() {
    return (
      <div>
          <h2>class comp</h2>
           <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptates vel officia tempore aperiam est fuga laudantium quis eligendi dolorem velit. Dignissimos impedit deserunt laudantium blanditiis cupiditate repudiandae sapiente at doloribus?</p>
      </div>
    )
  }
}
