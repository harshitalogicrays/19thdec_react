// function FirstFuncomp(){
//     return(
//         <h1>Hello from first functional comp</h1>
//     )
// }
// export default FirstFuncomp

// const FirstFuncomp = ()=>{
//     return(
//         <h1>Hello from first functional comp</h1>
//     )
// }
// export default FirstFuncomp

//rfc
// import React from 'react'

// export default function FirstFuncomp() {
//   return (
//     <div>
      
//     </div>
//   )
// }

//rafc
import React from 'react'

const FirstFuncomp = () => {
  return (
    <div>
      <h1>Hello from first functional comp</h1>
    </div>
  )
}

export default FirstFuncomp
